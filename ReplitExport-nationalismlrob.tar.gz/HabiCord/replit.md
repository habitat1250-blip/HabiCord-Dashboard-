# HabiStatTrack - Roblox Group Management Dashboard

## Overview
HabiStatTrack (also known as HabiCord Dashboard) is a comprehensive full-stack web application designed for managing Roblox group activities, player tracking, sessions, promotions, and administrative tasks. The application provides a modern gaming dashboard interface for group administrators to efficiently manage their Roblox communities.

## Purpose & Goals
- **Group Management**: Track and manage Roblox group members, ranks, and activities
- **Session Tracking**: Schedule, host, and monitor group sessions/events
- **Player Analytics**: Monitor player activity scores, attendance, and engagement
- **Administrative Tools**: Handle promotions, bans, leave of absence requests
- **Discord Integration**: Notify group members via Discord webhooks
- **API Management**: Generate and manage API keys for external integrations

## Current State
The application is fully configured and running in the Replit environment with:
- Frontend: React + Vite + Tailwind CSS
- Backend: Express + TypeScript
- Database: PostgreSQL (Neon serverless) with Drizzle ORM
- Authentication: Passport.js with session management
- Port: 5000 (both frontend and backend on same port)
- Status: Development server running successfully

## Recent Changes (November 2, 2025)
- Imported project from GitHub archive
- Installed Node.js 20 and all dependencies
- Set up PostgreSQL database and pushed schema migrations
- Configured development workflow on port 5000
- Configured deployment settings for Replit Autoscale

## Project Architecture

### Tech Stack
**Frontend:**
- React 18 with TypeScript
- Vite for build tooling and dev server
- Tailwind CSS + Radix UI components
- TanStack React Query for data fetching
- Wouter for routing
- React Hook Form + Zod for form validation

**Backend:**
- Express.js with TypeScript
- Passport.js for authentication (local strategy)
- WebSocket support (ws package)
- Session management with express-session
- PostgreSQL connection via Neon serverless driver

**Database:**
- PostgreSQL (managed by Replit)
- Drizzle ORM for type-safe queries
- Schema includes: users, groups, players, sessions, promotions, bans, leave of absence, API keys, activity logs

**Development Tools:**
- tsx for running TypeScript in development
- esbuild for production builds
- Drizzle Kit for database migrations
- ESLint + TypeScript for code quality

### Directory Structure
```
/
├── client/                 # Frontend React application
│   ├── public/            # Static assets (favicon)
│   └── src/
│       ├── components/    # React components
│       │   ├── ui/       # Radix UI component library
│       │   ├── app-sidebar.tsx
│       │   └── theme-*.tsx
│       ├── pages/        # Route pages
│       │   ├── dashboard.tsx
│       │   ├── players.tsx
│       │   ├── sessions.tsx
│       │   ├── promotions.tsx
│       │   ├── banlist.tsx
│       │   ├── loa.tsx (Leave of Absence)
│       │   ├── leaderboard.tsx
│       │   ├── api-keys.tsx
│       │   ├── discord-bot.tsx
│       │   ├── group-settings.tsx
│       │   └── login.tsx
│       ├── hooks/        # Custom React hooks
│       ├── lib/          # Utilities and query client
│       ├── App.tsx       # Main app component
│       └── main.tsx      # Entry point
├── server/               # Backend Express application
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API route handlers
│   ├── db.ts            # Database connection
│   ├── vite.ts          # Vite middleware setup
│   └── storage.ts       # Session storage
├── shared/              # Shared code between frontend/backend
│   └── schema.ts        # Drizzle database schema
├── attached_assets/     # Uploaded assets/images
├── vite.config.ts       # Vite configuration
├── drizzle.config.ts    # Drizzle ORM configuration
├── tailwind.config.ts   # Tailwind CSS configuration
└── package.json         # Dependencies and scripts
```

### Database Schema
**Core Tables:**
- `users` - Admin users who manage the dashboard
- `groups` - Roblox groups being managed
- `players` - Roblox players in tracked groups
- `sessions` - Group events/sessions
- `promotions` - Rank promotion history
- `bans` - Player ban records
- `leave_of_absence` - LOA requests
- `api_keys` - API key management
- `activity_logs` - Player activity tracking

**Key Relationships:**
- Groups belong to admin users (owner)
- Players belong to groups
- Sessions, promotions, bans, and LOAs are scoped to groups
- Activity logs track player actions

### Configuration Files
- **vite.config.ts**: Frontend build configuration with Replit plugins
- **drizzle.config.ts**: Database migration settings
- **tailwind.config.ts**: Tailwind CSS theming
- **tsconfig.json**: TypeScript compiler options
- **components.json**: Shadcn UI component configuration

## Key Features

### Dashboard Views
1. **Dashboard**: Overview with key statistics and recent activity
2. **Players**: Browse and manage group members
3. **Sessions**: Schedule and track group events
4. **Promotions**: Record and review rank changes
5. **Banlist**: Manage banned players
6. **Leave of Absence**: Track LOA requests
7. **Leaderboard**: Player activity rankings
8. **API Keys**: Generate keys for external integrations
9. **Discord Bot**: Configure Discord webhook notifications
10. **Group Settings**: Manage group configuration and bot settings

### Technical Features
- **Authentication**: User login with session persistence
- **Real-time Updates**: WebSocket support for live data
- **Responsive Design**: Mobile-first Tailwind CSS layouts
- **Type Safety**: Full TypeScript coverage
- **Theme Support**: Light/dark mode toggle
- **Form Validation**: Zod schemas for data validation

## Environment Variables
The application uses the following environment variables:
- `DATABASE_URL` - PostgreSQL connection string (auto-configured by Replit)
- `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE` - Individual DB credentials
- `NODE_ENV` - Environment mode (development/production)
- `PORT` - Server port (defaults to 5000)

## Available Scripts
- `npm run dev` - Start development server (tsx + Vite HMR)
- `npm run build` - Build for production (Vite + esbuild)
- `npm run start` - Run production build
- `npm run check` - TypeScript type checking
- `npm run db:push` - Push database schema changes

## Deployment Configuration
- **Target**: Replit Autoscale (stateless web app)
- **Build**: `npm run build`
- **Run**: `npm run start`
- **Port**: 5000 (automatically configured)

## Design System
The application follows a comprehensive design system documented in `design_guidelines.md`:
- **Typography**: Inter font family with JetBrains Mono for technical text
- **Color Scheme**: Gaming dashboard aesthetic inspired by Discord/Steam
- **Components**: Radix UI primitives with custom styling
- **Layout**: Sidebar navigation with responsive grid layouts
- **Spacing**: Consistent Tailwind spacing scale (2, 4, 6, 8, 12, 16)

## User Preferences
None specified yet.

## Development Notes
- Server uses middleware mode for Vite in development
- HMR (Hot Module Replacement) enabled via WebSocket
- Cache headers configured for proper reload behavior
- Database uses Neon serverless with WebSocket connections
- Session storage uses connect-pg-simple for PostgreSQL

## Known Issues
None at this time. All systems operational.

## Next Steps / TODO
- Configure Roblox OAuth integration (if needed)
- Set up Discord bot webhook integration
- Add authentication for admin users
- Populate initial group and player data
- Test all CRUD operations
