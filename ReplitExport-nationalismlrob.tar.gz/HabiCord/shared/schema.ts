import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  robloxId: text("roblox_id").notNull().unique(),
  username: text("username").notNull(),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  isAdmin: boolean("is_admin").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const groups = pgTable("groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  robloxGroupId: text("roblox_group_id").notNull().unique(),
  groupName: text("group_name").notNull(),
  ownerId: varchar("owner_id").notNull().references(() => users.id),
  rankBotRobloxId: text("rank_bot_roblox_id"),
  rankBotCookie: text("rank_bot_cookie"),
  discordWebhookUrl: text("discord_webhook_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const players = pgTable("players", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  robloxId: text("roblox_id").notNull().unique(),
  username: text("username").notNull(),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  groupId: varchar("group_id").references(() => groups.id),
  rank: text("rank"),
  team: text("team"),
  activityScore: integer("activity_score").notNull().default(0),
  lastSeenAt: timestamp("last_seen_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  hostId: varchar("host_id").notNull().references(() => players.id),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("upcoming"),
  playerCount: integer("player_count").notNull().default(0),
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  discordNotified: boolean("discord_notified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const promotions = pgTable("promotions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  promotedById: varchar("promoted_by_id").notNull().references(() => users.id),
  oldRank: text("old_rank").notNull(),
  newRank: text("new_rank").notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const bans = pgTable("bans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  bannedById: varchar("banned_by_id").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  duration: text("duration"),
  isActive: boolean("is_active").notNull().default(true),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const leaveOfAbsence = pgTable("leave_of_absence", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  reason: text("reason").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const apiKeys = pgTable("api_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().references(() => players.id),
  groupId: varchar("group_id").notNull().references(() => groups.id),
  activityType: text("activity_type").notNull(),
  duration: integer("duration"),
  metadata: text("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const usersRelations = relations(users, ({ many, one }) => ({
  ownedGroups: many(groups),
  promotionsGiven: many(promotions),
  bansIssued: many(bans),
}));

export const groupsRelations = relations(groups, ({ one, many }) => ({
  owner: one(users, {
    fields: [groups.ownerId],
    references: [users.id],
  }),
  players: many(players),
  sessions: many(sessions),
  promotions: many(promotions),
  bans: many(bans),
  leaveOfAbsence: many(leaveOfAbsence),
  apiKeys: many(apiKeys),
  activityLogs: many(activityLogs),
}));

export const playersRelations = relations(players, ({ one, many }) => ({
  group: one(groups, {
    fields: [players.groupId],
    references: [groups.id],
  }),
  hostedSessions: many(sessions),
  promotions: many(promotions),
  bans: many(bans),
  leaveOfAbsence: many(leaveOfAbsence),
  activityLogs: many(activityLogs),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  group: one(groups, {
    fields: [sessions.groupId],
    references: [groups.id],
  }),
  host: one(players, {
    fields: [sessions.hostId],
    references: [players.id],
  }),
}));

export const promotionsRelations = relations(promotions, ({ one }) => ({
  player: one(players, {
    fields: [promotions.playerId],
    references: [players.id],
  }),
  group: one(groups, {
    fields: [promotions.groupId],
    references: [groups.id],
  }),
  promotedBy: one(users, {
    fields: [promotions.promotedById],
    references: [users.id],
  }),
}));

export const bansRelations = relations(bans, ({ one }) => ({
  player: one(players, {
    fields: [bans.playerId],
    references: [players.id],
  }),
  group: one(groups, {
    fields: [bans.groupId],
    references: [groups.id],
  }),
  bannedBy: one(users, {
    fields: [bans.bannedById],
    references: [users.id],
  }),
}));

export const leaveOfAbsenceRelations = relations(leaveOfAbsence, ({ one }) => ({
  player: one(players, {
    fields: [leaveOfAbsence.playerId],
    references: [players.id],
  }),
  group: one(groups, {
    fields: [leaveOfAbsence.groupId],
    references: [groups.id],
  }),
}));

export const apiKeysRelations = relations(apiKeys, ({ one }) => ({
  group: one(groups, {
    fields: [apiKeys.groupId],
    references: [groups.id],
  }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  player: one(players, {
    fields: [activityLogs.playerId],
    references: [players.id],
  }),
  group: one(groups, {
    fields: [activityLogs.groupId],
    references: [groups.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  createdAt: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export const insertPromotionSchema = createInsertSchema(promotions).omit({
  id: true,
  createdAt: true,
});

export const insertBanSchema = createInsertSchema(bans).omit({
  id: true,
  createdAt: true,
});

export const insertLeaveOfAbsenceSchema = createInsertSchema(leaveOfAbsence).omit({
  id: true,
  createdAt: true,
});

export const insertApiKeySchema = createInsertSchema(apiKeys).omit({
  id: true,
  createdAt: true,
  key: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export type InsertPromotion = z.infer<typeof insertPromotionSchema>;
export type Promotion = typeof promotions.$inferSelect;

export type InsertBan = z.infer<typeof insertBanSchema>;
export type Ban = typeof bans.$inferSelect;

export type InsertLeaveOfAbsence = z.infer<typeof insertLeaveOfAbsenceSchema>;
export type LeaveOfAbsence = typeof leaveOfAbsence.$inferSelect;

export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKey = typeof apiKeys.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
