# HabiCord Dashboard - Design Guidelines

## Design Approach

**Selected Approach:** Design System with Gaming Dashboard References

Drawing inspiration from Discord, Steam, and modern gaming admin tools, this design emphasizes information hierarchy, data clarity, and efficient workflows while maintaining a professional gaming aesthetic. The system prioritizes scannable data displays, quick access to critical functions, and streamlined admin operations.

**Core Design Principles:**
1. Data-First Hierarchy: Statistics and player information are immediately scannable
2. Administrative Efficiency: Common tasks accessible within 2 clicks
3. Visual Clarity: Clean separation between functional zones
4. Gaming Professional: Polished, modern interface suitable for serious game management

---

## Typography System

**Font Families:**
- Primary: Inter (Google Fonts) - All UI elements, body text, data displays
- Accent: JetBrains Mono (Google Fonts) - API keys, code snippets, technical data

**Type Scale:**
- Hero/Dashboard Title: text-4xl font-bold (HabiCord branding)
- Section Headers: text-2xl font-semibold
- Card Titles: text-lg font-semibold
- Subsection Headers: text-base font-medium
- Body Text: text-sm font-normal
- Data/Stats: text-sm font-medium (numbers), text-xs font-normal (labels)
- Labels/Meta: text-xs font-medium uppercase tracking-wide
- Technical Text: text-sm font-mono (API keys)

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, and 16
- Micro spacing (gaps, padding): 2, 4
- Component spacing: 6, 8
- Section spacing: 12, 16
- Page margins: 8, 12

**Grid Structure:**
```
Dashboard Layout:
- Sidebar: Fixed 64 width (w-64) on desktop, hidden on mobile with hamburger menu
- Main Content: flex-1 with max-w-7xl container, px-6 py-8
- Responsive breakpoints: Mobile-first, sidebar collapses < lg

Section Layouts:
- Stats Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Player Tables: Full-width tables with horizontal scroll on mobile
- Two-Column Forms: grid-cols-1 lg:grid-cols-2 gap-8
- Session Cards: grid-cols-1 md:grid-cols-2 gap-6
```

**Container Rules:**
- Dashboard container: max-w-7xl mx-auto
- Card containers: Rounded-lg with border, p-6
- Form containers: p-8 with clear visual separation
- Table containers: Overflow-x-auto with sticky headers

---

## Component Library

### Navigation Components

**Sidebar Navigation:**
- Logo placement at top with HabiCord branding (h-16 flex items-center px-6)
- Navigation items: flex items-center px-6 py-3 gap-3
- Icon size: w-5 h-5 for nav icons (Heroicons)
- Active state: Border-l-4 indicator
- Sections: Dashboard, Players, Sessions, Management (LoA, Banlist), Leaderboards, API Keys, Group Settings, Promotions, Discord Bot
- Bottom section: User profile display (avatar + username) and logout

**Mobile Navigation:**
- Hamburger menu button: w-10 h-10 in top-left
- Slide-in drawer overlay for mobile menu
- Close button in drawer

### Dashboard Components

**Statistics Cards:**
- Grid layout: 4 columns on desktop, 2 on tablet, 1 on mobile
- Card structure: Icon + Label + Large Number + Trend Indicator
- Icon placement: Top-left, w-12 h-12
- Number display: text-3xl font-bold
- Label: text-sm uppercase tracking-wide
- Height: h-32 for consistency
- Cards include: Active Players, Total Sessions Today, Pending Promotions, Banned Players

**Player Search:**
- Search bar: Full-width input with search icon (h-12, rounded-lg)
- Results display: Cards below search (avatar + username + quick stats)
- Quick actions: View Profile, View Activity buttons

### Data Display Components

**Player Tables:**
- Header row: Sticky top, font-semibold, text-xs uppercase
- Row height: h-16 for comfortable scanning
- Columns: Avatar (w-10 h-10 rounded-full), Username, Rank, Activity Status, Last Seen, Actions
- Pagination: Bottom-center with page numbers
- Sort indicators: Arrow icons in headers
- Hover state: Subtle row highlight

**Leaderboard Display:**
- Rank badges: #1-3 special treatment (larger, distinct styling)
- List items: Rank number + Avatar + Player Name + Score/Metric
- Item height: h-20
- Top 3: Larger avatars (w-16 h-16), rest (w-12 h-12)

**Session Cards:**
- Card layout: Host avatar + Session title + Player count + Time
- Status indicator: Live/Upcoming badge (top-right)
- Host button: Prominent CTA (h-12, full-width)
- Discord notification toggle: Checkbox with label

### Forms & Input Components

**API Key Management:**
- Key display: Monospace font in read-only input field
- Copy button: Inline with input (h-10)
- Regenerate button: Warning-styled, confirmation modal
- Instructions panel: Step-by-step numbered list with code snippets
- Key visibility toggle icon

**Group Connection Form:**
- Two-step process: 1) Connect Group, 2) Configure Permissions
- Group ID input: Large, clear label
- Status indicator: Connected/Not Connected with icon
- Admin list: Table showing who has access

**Promotion Management:**
- Player selector: Searchable dropdown
- Current rank → New rank visual flow
- Cooldown indicator: Progress bar or days remaining display
- Promotion history table: Player + Old Rank + New Rank + Date + Promoted By
- Rank bot credentials: Secure input fields with show/hide toggle

**LoA & Banlist Forms:**
- LoA: Player search + Date range picker + Reason textarea
- Banlist: Player search + Reason + Ban duration dropdown
- Action buttons: Add/Remove with confirmation modals

### Integration Components

**Discord Bot Section:**
- Hero display: Bot avatar + Bot name + Status (Online/Offline)
- Invite button: Large CTA linking to provided URL, h-14
- Features list: Checkmarks with feature descriptions
- Configuration panel: Webhook URL input, test notification button

**Roblox OAuth Login:**
- Landing page: Centered card (max-w-md)
- Roblox logo display
- Single "Login with Roblox" button (h-14, full-width)
- Security notice: Small text below button

### UI Patterns

**Cards:**
- Standard: rounded-lg border p-6
- Elevated: rounded-lg border shadow-lg p-6
- Interactive: Hover state with subtle lift (transition-transform)

**Buttons:**
- Primary CTA: h-12 px-6 rounded-lg font-semibold
- Secondary: h-10 px-4 rounded-md font-medium border
- Icon buttons: w-10 h-10 rounded-md
- Danger: Warning styling for destructive actions

**Badges:**
- Status badges: px-3 py-1 rounded-full text-xs font-medium uppercase
- Count badges: Circular, w-6 h-6 text-xs centered

**Modals:**
- Overlay: Fixed inset with backdrop blur
- Content: max-w-lg centered, rounded-lg p-8
- Header: text-xl font-bold mb-4
- Actions: Footer with Cancel + Confirm buttons

**Empty States:**
- Icon (w-16 h-16) + Message + Call-to-action
- Used for: No search results, Empty leaderboards, No sessions

---

## Accessibility Implementation

- Semantic HTML throughout (nav, main, section, article)
- ARIA labels for all interactive elements
- Keyboard navigation: Full tab order, visible focus states
- Focus rings: ring-2 ring-offset-2 on all interactive elements
- Form labels: Always visible, associated with inputs
- Error states: Clear messaging with icons
- Skip to main content link
- Minimum touch target: 44x44px (h-11 minimum for buttons)

---

## Images & Visual Assets

**Logo Integration:**
- HabiCord logo (provided image): Display in sidebar top (h-10), login page (h-16), and dashboard header
- Placement: Left-aligned in sidebar with text "HabiCord" (text-xl font-bold)

**Player Avatars:**
- Fetched from Roblox API using player IDs
- Sizes: Small (w-8 h-8), Medium (w-12 h-12), Large (w-16 h-16)
- Shape: rounded-full with subtle border
- Fallback: Generic user icon from Heroicons

**Icons:**
- Library: Heroicons (outline for navigation, solid for status indicators)
- Dashboard: ChartBarIcon, UsersIcon, ClockIcon, ShieldExclamationIcon
- Navigation: HomeIcon, UserGroupIcon, CalendarIcon, KeyIcon, TrophyIcon
- Actions: PencilIcon, TrashIcon, CheckIcon, XMarkIcon
- Status: CheckCircleIcon (active), ExclamationCircleIcon (warning)

**No Hero Image:** This is a dashboard application focused on data and functionality, not a marketing page. The login page uses logo-centric branding instead of hero imagery.