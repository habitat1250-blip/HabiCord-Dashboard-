import { 
  users, groups, players, sessions, promotions, bans, leaveOfAbsence, apiKeys, activityLogs,
  type User, type InsertUser,
  type Group, type InsertGroup,
  type Player, type InsertPlayer,
  type Session, type InsertSession,
  type Promotion, type InsertPromotion,
  type Ban, type InsertBan,
  type LeaveOfAbsence, type InsertLeaveOfAbsence,
  type ApiKey, type InsertApiKey,
  type ActivityLog, type InsertActivityLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByRobloxId(robloxId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Groups
  getGroup(id: string): Promise<Group | undefined>;
  getGroupByRobloxId(robloxGroupId: string): Promise<Group | undefined>;
  createGroup(group: InsertGroup): Promise<Group>;
  updateGroup(id: string, group: Partial<InsertGroup>): Promise<Group | undefined>;

  // Players
  getPlayer(id: string): Promise<Player | undefined>;
  getPlayerByRobloxId(robloxId: string): Promise<Player | undefined>;
  getPlayers(groupId?: string): Promise<Player[]>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayer(id: string, player: Partial<InsertPlayer>): Promise<Player | undefined>;

  // Sessions
  getSession(id: string): Promise<Session | undefined>;
  getSessions(groupId: string): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined>;

  // Promotions
  getPromotion(id: string): Promise<Promotion | undefined>;
  getPromotions(groupId: string): Promise<Promotion[]>;
  getPlayerPromotions(playerId: string): Promise<Promotion[]>;
  createPromotion(promotion: InsertPromotion): Promise<Promotion>;

  // Bans
  getBan(id: string): Promise<Ban | undefined>;
  getBans(groupId: string): Promise<Ban[]>;
  createBan(ban: InsertBan): Promise<Ban>;
  updateBan(id: string, ban: Partial<InsertBan>): Promise<Ban | undefined>;
  deleteBan(id: string): Promise<void>;

  // Leave of Absence
  getLeaveOfAbsence(id: string): Promise<LeaveOfAbsence | undefined>;
  getLeaveOfAbsences(groupId: string): Promise<LeaveOfAbsence[]>;
  createLeaveOfAbsence(loa: InsertLeaveOfAbsence): Promise<LeaveOfAbsence>;
  deleteLeaveOfAbsence(id: string): Promise<void>;

  // API Keys
  getApiKey(id: string): Promise<ApiKey | undefined>;
  getApiKeyByKey(key: string): Promise<ApiKey | undefined>;
  getApiKeys(groupId: string): Promise<ApiKey[]>;
  createApiKey(apiKey: InsertApiKey): Promise<ApiKey>;
  deleteApiKey(id: string): Promise<void>;

  // Activity Logs
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogs(groupId: string, playerId?: string): Promise<ActivityLog[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByRobloxId(robloxId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.robloxId, robloxId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Groups
  async getGroup(id: string): Promise<Group | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.id, id));
    return group || undefined;
  }

  async getGroupByRobloxId(robloxGroupId: string): Promise<Group | undefined> {
    const [group] = await db.select().from(groups).where(eq(groups.robloxGroupId, robloxGroupId));
    return group || undefined;
  }

  async createGroup(insertGroup: InsertGroup): Promise<Group> {
    const [group] = await db.insert(groups).values(insertGroup).returning();
    return group;
  }

  async updateGroup(id: string, updateGroup: Partial<InsertGroup>): Promise<Group | undefined> {
    const [group] = await db.update(groups).set(updateGroup).where(eq(groups.id, id)).returning();
    return group || undefined;
  }

  // Players
  async getPlayer(id: string): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player || undefined;
  }

  async getPlayerByRobloxId(robloxId: string): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.robloxId, robloxId));
    return player || undefined;
  }

  async getPlayers(groupId?: string): Promise<Player[]> {
    if (groupId) {
      return await db.select().from(players).where(eq(players.groupId, groupId)).orderBy(desc(players.activityScore));
    }
    return await db.select().from(players).orderBy(desc(players.activityScore));
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const [player] = await db.insert(players).values(insertPlayer).returning();
    return player;
  }

  async updatePlayer(id: string, updatePlayer: Partial<InsertPlayer>): Promise<Player | undefined> {
    const [player] = await db.update(players).set(updatePlayer).where(eq(players.id, id)).returning();
    return player || undefined;
  }

  // Sessions
  async getSession(id: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session || undefined;
  }

  async getSessions(groupId: string): Promise<Session[]> {
    return await db.select().from(sessions).where(eq(sessions.groupId, groupId)).orderBy(desc(sessions.createdAt));
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(insertSession).returning();
    return session;
  }

  async updateSession(id: string, updateSession: Partial<InsertSession>): Promise<Session | undefined> {
    const [session] = await db.update(sessions).set(updateSession).where(eq(sessions.id, id)).returning();
    return session || undefined;
  }

  // Promotions
  async getPromotion(id: string): Promise<Promotion | undefined> {
    const [promotion] = await db.select().from(promotions).where(eq(promotions.id, id));
    return promotion || undefined;
  }

  async getPromotions(groupId: string): Promise<Promotion[]> {
    return await db.select().from(promotions).where(eq(promotions.groupId, groupId)).orderBy(desc(promotions.createdAt));
  }

  async getPlayerPromotions(playerId: string): Promise<Promotion[]> {
    return await db.select().from(promotions).where(eq(promotions.playerId, playerId)).orderBy(desc(promotions.createdAt));
  }

  async createPromotion(insertPromotion: InsertPromotion): Promise<Promotion> {
    const [promotion] = await db.insert(promotions).values(insertPromotion).returning();
    return promotion;
  }

  // Bans
  async getBan(id: string): Promise<Ban | undefined> {
    const [ban] = await db.select().from(bans).where(eq(bans.id, id));
    return ban || undefined;
  }

  async getBans(groupId: string): Promise<Ban[]> {
    return await db.select().from(bans).where(eq(bans.groupId, groupId)).orderBy(desc(bans.createdAt));
  }

  async createBan(insertBan: InsertBan): Promise<Ban> {
    const [ban] = await db.insert(bans).values(insertBan).returning();
    return ban;
  }

  async updateBan(id: string, updateBan: Partial<InsertBan>): Promise<Ban | undefined> {
    const [ban] = await db.update(bans).set(updateBan).where(eq(bans.id, id)).returning();
    return ban || undefined;
  }

  async deleteBan(id: string): Promise<void> {
    await db.delete(bans).where(eq(bans.id, id));
  }

  // Leave of Absence
  async getLeaveOfAbsence(id: string): Promise<LeaveOfAbsence | undefined> {
    const [loa] = await db.select().from(leaveOfAbsence).where(eq(leaveOfAbsence.id, id));
    return loa || undefined;
  }

  async getLeaveOfAbsences(groupId: string): Promise<LeaveOfAbsence[]> {
    return await db.select().from(leaveOfAbsence).where(eq(leaveOfAbsence.groupId, groupId)).orderBy(desc(leaveOfAbsence.createdAt));
  }

  async createLeaveOfAbsence(insertLoa: InsertLeaveOfAbsence): Promise<LeaveOfAbsence> {
    const [loa] = await db.insert(leaveOfAbsence).values(insertLoa).returning();
    return loa;
  }

  async deleteLeaveOfAbsence(id: string): Promise<void> {
    await db.delete(leaveOfAbsence).where(eq(leaveOfAbsence.id, id));
  }

  // API Keys
  async getApiKey(id: string): Promise<ApiKey | undefined> {
    const [apiKey] = await db.select().from(apiKeys).where(eq(apiKeys.id, id));
    return apiKey || undefined;
  }

  async getApiKeyByKey(key: string): Promise<ApiKey | undefined> {
    const [apiKey] = await db.select().from(apiKeys).where(eq(apiKeys.key, key));
    return apiKey || undefined;
  }

  async getApiKeys(groupId: string): Promise<ApiKey[]> {
    return await db.select().from(apiKeys).where(eq(apiKeys.groupId, groupId)).orderBy(desc(apiKeys.createdAt));
  }

  async createApiKey(insertApiKey: InsertApiKey): Promise<ApiKey> {
    const [apiKey] = await db.insert(apiKeys).values(insertApiKey).returning();
    return apiKey;
  }

  async deleteApiKey(id: string): Promise<void> {
    await db.delete(apiKeys).where(eq(apiKeys.id, id));
  }

  // Activity Logs
  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db.insert(activityLogs).values(insertLog).returning();
    return log;
  }

  async getActivityLogs(groupId: string, playerId?: string): Promise<ActivityLog[]> {
    if (playerId) {
      return await db.select().from(activityLogs)
        .where(and(eq(activityLogs.groupId, groupId), eq(activityLogs.playerId, playerId)))
        .orderBy(desc(activityLogs.createdAt));
    }
    return await db.select().from(activityLogs).where(eq(activityLogs.groupId, groupId)).orderBy(desc(activityLogs.createdAt));
  }
}

export const storage = new DatabaseStorage();
