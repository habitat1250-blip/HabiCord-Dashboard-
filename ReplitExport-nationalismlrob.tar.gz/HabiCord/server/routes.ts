import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { randomBytes } from "crypto";
import {
  insertSessionSchema,
  insertPromotionSchema,
  insertBanSchema,
  insertLeaveOfAbsenceSchema,
  insertApiKeySchema,
  insertGroupSchema,
  insertPlayerSchema,
  insertActivityLogSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock authentication middleware (would be replaced with real Roblox OAuth)
  const requireAuth = (req: any, res: any, next: any) => {
    // In production, this would validate a Roblox OAuth session
    // For now, using a hardcoded mock user
    req.user = { id: "admin-user-123", robloxId: "123456", username: "AdminUser" };
    req.groupId = "default-group-123"; // Would come from user's linked group
    next();
  };

  // Helper to send Discord webhook
  const sendDiscordWebhook = async (webhookUrl: string, content: any) => {
    if (!webhookUrl) return;
    try {
      const fetch = (await import('node-fetch')).default;
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(content),
      });
    } catch (error) {
      console.error('Discord webhook error:', error);
    }
  };

  // Helper to check promotion cooldown (7 days)
  const canPromotePlayer = async (playerId: string): Promise<boolean> => {
    const promotions = await storage.getPlayerPromotions(playerId);
    if (promotions.length === 0) return true;
    
    const lastPromotion = promotions[0];
    const daysSincePromotion = (Date.now() - new Date(lastPromotion.createdAt).getTime()) / (1000 * 60 * 60 * 24);
    return daysSincePromotion >= 7;
  };

  // Stats endpoint
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const groupId = req.groupId;
      const sessions = await storage.getSessions(groupId);
      const players = await storage.getPlayers(groupId);
      const bans = await storage.getBans(groupId);
      const promotions = await storage.getPromotions(groupId);

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const sessionsToday = sessions.filter(s => {
        const sessionDate = new Date(s.createdAt);
        sessionDate.setHours(0, 0, 0, 0);
        return sessionDate.getTime() === today.getTime();
      }).length;

      const activePlayers = players.filter(p => {
        if (!p.lastSeenAt) return false;
        const lastSeen = new Date(p.lastSeenAt);
        const hoursSince = (Date.now() - lastSeen.getTime()) / (1000 * 60 * 60);
        return hoursSince < 24;
      }).length;

      const activeBans = bans.filter(b => b.isActive).length;

      // Count promotions from last 7 days
      const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      const pendingPromotions = promotions.filter(p => {
        return new Date(p.createdAt).getTime() > sevenDaysAgo;
      }).length;

      res.json({
        activePlayers,
        sessionsToday,
        pendingPromotions,
        activeBans,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Players endpoints
  app.get("/api/players", requireAuth, async (req, res) => {
    try {
      const groupId = req.groupId;
      const players = await storage.getPlayers(groupId);
      res.json(players);
    } catch (error) {
      console.error("Error fetching players:", error);
      res.status(500).json({ error: "Failed to fetch players" });
    }
  });

  app.post("/api/players", requireAuth, async (req, res) => {
    try {
      const validatedData = insertPlayerSchema.parse(req.body);
      const player = await storage.createPlayer(validatedData);
      res.json(player);
    } catch (error) {
      console.error("Error creating player:", error);
      res.status(400).json({ error: "Failed to create player" });
    }
  });

  // Sessions endpoints
  app.get("/api/sessions", requireAuth, async (req, res) => {
    try {
      const groupId = req.groupId;
      const sessions = await storage.getSessions(groupId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.post("/api/sessions", requireAuth, async (req, res) => {
    try {
      const { title, description, notifyDiscord } = req.body;
      
      // Get the group to check webhook URL
      const group = await storage.getGroup(req.groupId);
      
      const sessionData = {
        groupId: req.groupId,
        hostId: req.user.id, // Using logged-in user as host
        title,
        description: description || null,
        status: "upcoming",
        playerCount: 0,
        scheduledAt: new Date(),
        discordNotified: false,
      };

      const session = await storage.createSession(sessionData);

      // Send Discord webhook if enabled and URL is configured
      if (notifyDiscord && group?.discordWebhookUrl) {
        await sendDiscordWebhook(group.discordWebhookUrl, {
          embeds: [{
            title: "🎮 New Session Started!",
            description: `**${title}**${description ? `\n${description}` : ''}`,
            color: 0x3B82F6,
            fields: [
              { name: "Host", value: req.user.username, inline: true },
              { name: "Time", value: new Date().toLocaleString(), inline: true },
            ],
          }],
        });
        await storage.updateSession(session.id, { discordNotified: true });
      }

      res.json(session);
    } catch (error) {
      console.error("Error creating session:", error);
      res.status(400).json({ error: "Failed to create session" });
    }
  });

  // Promotions endpoints
  app.get("/api/promotions", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const promotions = await storage.getPromotions(groupId);
      res.json(promotions);
    } catch (error) {
      console.error("Error fetching promotions:", error);
      res.status(500).json({ error: "Failed to fetch promotions" });
    }
  });

  app.post("/api/promotions", requireAuth, async (req, res) => {
    try {
      const { playerSearch, currentRank, newRank, reason } = req.body;

      const promotionData = {
        playerId: "mock-player-id",
        groupId: "mock-group-id",
        promotedById: req.user.id,
        oldRank: currentRank,
        newRank,
        reason: reason || null,
      };

      const promotion = await storage.createPromotion(promotionData);
      res.json(promotion);
    } catch (error) {
      console.error("Error creating promotion:", error);
      res.status(400).json({ error: "Failed to create promotion" });
    }
  });

  // Bans endpoints
  app.get("/api/bans", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const bans = await storage.getBans(groupId);
      res.json(bans);
    } catch (error) {
      console.error("Error fetching bans:", error);
      res.status(500).json({ error: "Failed to fetch bans" });
    }
  });

  app.post("/api/bans", requireAuth, async (req, res) => {
    try {
      const { playerSearch, reason, duration } = req.body;

      const banData = {
        playerId: "mock-player-id",
        groupId: "mock-group-id",
        bannedById: req.user.id,
        reason,
        duration,
        isActive: true,
        expiresAt: duration !== "permanent" ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) : null,
      };

      const ban = await storage.createBan(banData);
      res.json(ban);
    } catch (error) {
      console.error("Error creating ban:", error);
      res.status(400).json({ error: "Failed to create ban" });
    }
  });

  app.delete("/api/bans/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteBan(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting ban:", error);
      res.status(500).json({ error: "Failed to delete ban" });
    }
  });

  // Leave of Absence endpoints
  app.get("/api/loa", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const loas = await storage.getLeaveOfAbsences(groupId);
      res.json(loas);
    } catch (error) {
      console.error("Error fetching LoAs:", error);
      res.status(500).json({ error: "Failed to fetch LoAs" });
    }
  });

  app.post("/api/loa", requireAuth, async (req, res) => {
    try {
      const { playerSearch, startDate, endDate, reason } = req.body;

      const loaData = {
        playerId: "mock-player-id",
        groupId: "mock-group-id",
        reason,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        isActive: true,
      };

      const loa = await storage.createLeaveOfAbsence(loaData);
      res.json(loa);
    } catch (error) {
      console.error("Error creating LoA:", error);
      res.status(400).json({ error: "Failed to create LoA" });
    }
  });

  // API Keys endpoints
  app.get("/api/api-keys", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const apiKeys = await storage.getApiKeys(groupId);
      res.json(apiKeys);
    } catch (error) {
      console.error("Error fetching API keys:", error);
      res.status(500).json({ error: "Failed to fetch API keys" });
    }
  });

  app.post("/api/api-keys", requireAuth, async (req, res) => {
    try {
      const { name } = req.body;
      const key = `hc_${randomBytes(32).toString("hex")}`;

      const apiKeyData = {
        groupId: "mock-group-id",
        key,
        name,
        isActive: true,
      };

      const apiKey = await storage.createApiKey(apiKeyData);
      res.json(apiKey);
    } catch (error) {
      console.error("Error creating API key:", error);
      res.status(400).json({ error: "Failed to create API key" });
    }
  });

  app.delete("/api/api-keys/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteApiKey(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting API key:", error);
      res.status(500).json({ error: "Failed to delete API key" });
    }
  });

  // Group Settings endpoints
  app.get("/api/group-settings", requireAuth, async (req, res) => {
    try {
      const group = await storage.getGroup("mock-group-id");
      if (!group) {
        return res.json({ isConnected: false });
      }
      res.json({
        groupId: group.robloxGroupId,
        groupName: group.groupName,
        isConnected: true,
        rankBotConfigured: !!group.rankBotRobloxId,
        webhookConfigured: !!group.discordWebhookUrl,
        adminCount: 3,
      });
    } catch (error) {
      console.error("Error fetching group settings:", error);
      res.status(500).json({ error: "Failed to fetch group settings" });
    }
  });

  app.post("/api/group-settings", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const group = await storage.getGroup(groupId);
      
      if (!group) {
        const newGroupData = {
          robloxGroupId: req.body.robloxGroupId || "123456789",
          groupName: "HabiCord Official Group",
          ownerId: req.user.id,
          rankBotRobloxId: req.body.rankBotRobloxId || null,
          rankBotCookie: req.body.rankBotCookie || null,
          discordWebhookUrl: req.body.discordWebhookUrl || null,
        };
        const newGroup = await storage.createGroup(newGroupData);
        return res.json(newGroup);
      }

      const updated = await storage.updateGroup(groupId, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Error updating group settings:", error);
      res.status(400).json({ error: "Failed to update group settings" });
    }
  });

  // Leaderboard endpoints
  app.get("/api/leaderboard", requireAuth, async (req, res) => {
    try {
      const groupId = "mock-group-id";
      const players = await storage.getPlayers(groupId);
      res.json(players);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  // Activity logging endpoint (for Roblox API)
  app.post("/api/activity", async (req, res) => {
    try {
      const { apiKey, playerId, activityType, duration, metadata } = req.body;

      if (!apiKey) {
        return res.status(401).json({ error: "API key required" });
      }

      const key = await storage.getApiKeyByKey(apiKey);
      if (!key || !key.isActive) {
        return res.status(401).json({ error: "Invalid API key" });
      }

      const logData = {
        playerId,
        groupId: key.groupId,
        activityType,
        duration: duration || null,
        metadata: metadata ? JSON.stringify(metadata) : null,
      };

      const log = await storage.createActivityLog(logData);
      res.json({ success: true, log });
    } catch (error) {
      console.error("Error logging activity:", error);
      res.status(400).json({ error: "Failed to log activity" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
