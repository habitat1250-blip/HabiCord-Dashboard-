import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Key, Copy, Eye, EyeOff, RotateCw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

export default function ApiKeys() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [keyName, setKeyName] = useState("");
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  const { data: apiKeys } = useQuery({
    queryKey: ["/api/api-keys"],
  });

  const createKeyMutation = useMutation({
    mutationFn: async (name: string) => {
      return await apiRequest("POST", "/api/api-keys", { name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
      setIsDialogOpen(false);
      setKeyName("");
      toast({
        title: "API Key created",
        description: "Your new API key has been generated.",
      });
    },
  });

  const deleteKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      return await apiRequest("DELETE", `/api/api-keys/${keyId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
      toast({
        title: "API Key deleted",
        description: "The API key has been removed.",
      });
    },
  });

  const mockKeys = [
    {
      id: "1",
      name: "Production Game Server",
      key: "hc_1234567890abcdefghijklmnopqrstuvwxyz",
      isActive: true,
      createdAt: "2024-01-10T10:00:00Z",
    },
    {
      id: "2",
      name: "Development Server",
      key: "hc_abcdefghijklmnopqrstuvwxyz1234567890",
      isActive: true,
      createdAt: "2024-01-12T14:30:00Z",
    },
  ];

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast({
      title: "Copied to clipboard",
      description: "API key has been copied.",
    });
  };

  const toggleKeyVisibility = (keyId: string) => {
    setShowKeys(prev => ({ ...prev, [keyId]: !prev[keyId] }));
  };

  const displayKeys = apiKeys || mockKeys;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">API Keys</h1>
        <p className="text-muted-foreground">
          Manage API keys for connecting your Roblox game scripts to HabiCord
        </p>
      </div>

      <Alert>
        <Key className="h-4 w-4" />
        <AlertTitle>How to use API Keys</AlertTitle>
        <AlertDescription>
          Copy your API key and paste it into your Roblox game script to enable real-time player activity tracking and statistics.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Integration Instructions</CardTitle>
              <CardDescription className="mt-2">
                Follow these steps to connect your Roblox game
              </CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="lg" data-testid="button-generate-key">
                  <Plus className="mr-2 h-5 w-5" />
                  Generate New Key
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Generate API Key</DialogTitle>
                  <DialogDescription>
                    Create a new API key for your Roblox game server
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="keyName">Key Name *</Label>
                    <Input
                      id="keyName"
                      placeholder="e.g., Production Server"
                      value={keyName}
                      onChange={(e) => setKeyName(e.target.value)}
                      data-testid="input-key-name"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={() => createKeyMutation.mutate(keyName)}
                    disabled={!keyName || createKeyMutation.isPending}
                  >
                    {createKeyMutation.isPending ? "Generating..." : "Generate Key"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <ol className="space-y-4 text-sm">
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                1
              </span>
              <div>
                <p className="font-medium mb-1">Generate an API key above</p>
                <p className="text-muted-foreground">Click "Generate New Key" and give it a descriptive name</p>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                2
              </span>
              <div>
                <p className="font-medium mb-1">Copy the API key</p>
                <p className="text-muted-foreground">Click the copy icon to copy your API key to clipboard</p>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                3
              </span>
              <div>
                <p className="font-medium mb-1">Add to your Roblox game script</p>
                <p className="text-muted-foreground mb-2">In your Roblox Studio, create a ServerScript and paste:</p>
                <pre className="bg-muted p-3 rounded-md text-xs overflow-x-auto">
{`local HttpService = game:GetService("HttpService")
local API_KEY = "YOUR_API_KEY_HERE"
local API_URL = "https://habicord.repl.co/api"

-- Track player join
game.Players.PlayerAdded:Connect(function(player)
    HttpService:PostAsync(
        API_URL .. "/activity",
        HttpService:JSONEncode({
            apiKey = API_KEY,
            playerId = player.UserId,
            activityType = "join"
        })
    )
end)`}
                </pre>
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Your API Keys</h2>
        {displayKeys.map((apiKey: any) => (
          <Card key={apiKey.id} data-testid={`card-api-key-${apiKey.id}`}>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Key className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg mb-1">{apiKey.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Created {new Date(apiKey.createdAt).toLocaleDateString()}
                      </p>
                      <Badge variant={apiKey.isActive ? "default" : "outline"} className="mt-2">
                        {apiKey.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>API Key</Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        readOnly
                        type={showKeys[apiKey.id] ? "text" : "password"}
                        value={apiKey.key}
                        className="font-mono text-sm pr-10"
                        data-testid={`input-api-key-${apiKey.id}`}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                        onClick={() => toggleKeyVisibility(apiKey.id)}
                        data-testid={`button-toggle-visibility-${apiKey.id}`}
                      >
                        {showKeys[apiKey.id] ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleCopyKey(apiKey.key)}
                      data-testid={`button-copy-key-${apiKey.id}`}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteKeyMutation.mutate(apiKey.id)}
                      disabled={deleteKeyMutation.isPending}
                      data-testid={`button-delete-key-${apiKey.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
