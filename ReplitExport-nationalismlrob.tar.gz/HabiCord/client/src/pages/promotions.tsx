import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, TrendingUp, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Promotions() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    playerSearch: "",
    currentRank: "",
    newRank: "",
    reason: "",
  });
  const { toast } = useToast();

  const { data: promotions } = useQuery({
    queryKey: ["/api/promotions"],
  });

  const createPromotionMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/promotions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/promotions"] });
      setIsDialogOpen(false);
      setFormData({ playerSearch: "", currentRank: "", newRank: "", reason: "" });
      toast({
        title: "Promotion created",
        description: "Player promotion has been recorded.",
      });
    },
  });

  const mockPromotions = [
    {
      id: "1",
      player: {
        username: "PlayerPro",
        displayName: "Player Pro",
      },
      oldRank: "Member",
      newRank: "Officer",
      promotedBy: "AdminUser",
      reason: "Excellent leadership and activity",
      createdAt: "2024-01-14T10:00:00Z",
      lastPromotionDays: 15,
      canPromoteAgain: false,
    },
    {
      id: "2",
      player: {
        username: "NewPlayer99",
        displayName: "New Player",
      },
      oldRank: "Recruit",
      newRank: "Member",
      promotedBy: "GameMaster",
      reason: "Completed training successfully",
      createdAt: "2024-01-08T14:30:00Z",
      lastPromotionDays: 7,
      canPromoteAgain: true,
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createPromotionMutation.mutate(formData);
  };

  const getCooldownProgress = (days: number) => {
    return Math.min((days / 7) * 100, 100);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">Promotions</h1>
          <p className="text-muted-foreground">
            Manage player promotions with automatic 7-day cooldown tracking
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" data-testid="button-create-promotion">
              <Plus className="mr-2 h-5 w-5" />
              Promote Player
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>Promote Player</DialogTitle>
                <DialogDescription>
                  Promote a player to a higher rank. System will enforce 7-day cooldown.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="player">Player *</Label>
                  <Input
                    id="player"
                    placeholder="Search for player..."
                    value={formData.playerSearch}
                    onChange={(e) => setFormData({ ...formData, playerSearch: e.target.value })}
                    required
                    data-testid="input-promotion-player"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentRank">Current Rank *</Label>
                    <Select 
                      value={formData.currentRank} 
                      onValueChange={(value) => setFormData({ ...formData, currentRank: value })}
                    >
                      <SelectTrigger data-testid="select-current-rank">
                        <SelectValue placeholder="Select rank" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="recruit">Recruit</SelectItem>
                        <SelectItem value="member">Member</SelectItem>
                        <SelectItem value="officer">Officer</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newRank">New Rank *</Label>
                    <Select 
                      value={formData.newRank} 
                      onValueChange={(value) => setFormData({ ...formData, newRank: value })}
                    >
                      <SelectTrigger data-testid="select-new-rank">
                        <SelectValue placeholder="Select rank" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="member">Member</SelectItem>
                        <SelectItem value="officer">Officer</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reason">Reason</Label>
                  <Textarea
                    id="reason"
                    placeholder="Why is this player being promoted?"
                    value={formData.reason}
                    onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                    rows={3}
                    data-testid="input-promotion-reason"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createPromotionMutation.isPending}>
                  {createPromotionMutation.isPending ? "Processing..." : "Promote Player"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {mockPromotions.map((promotion: any) => (
          <Card key={promotion.id} data-testid={`card-promotion-${promotion.id}`}>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg">{promotion.player.username}</h3>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{promotion.oldRank}</Badge>
                          <span className="text-muted-foreground">→</span>
                          <Badge variant="default">{promotion.newRank}</Badge>
                        </div>
                      </div>
                      {promotion.reason && (
                        <p className="text-sm text-muted-foreground mb-3">{promotion.reason}</p>
                      )}
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>By {promotion.promotedBy}</span>
                        <span>•</span>
                        <span>{new Date(promotion.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Promotion Cooldown
                    </span>
                    {promotion.canPromoteAgain ? (
                      <span className="flex items-center gap-1 text-green-600">
                        <CheckCircle className="h-4 w-4" />
                        Can promote again
                      </span>
                    ) : (
                      <span className="text-muted-foreground">
                        {7 - promotion.lastPromotionDays} days remaining
                      </span>
                    )}
                  </div>
                  <Progress value={getCooldownProgress(promotion.lastPromotionDays)} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
