import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Login() {
  const handleRobloxLogin = () => {
    window.location.href = "/api/auth/roblox";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-6">
          <div className="flex justify-center">
            <img 
              src="/attached_assets/1761554633390_1762009837448.png" 
              alt="HabiCord Logo" 
              className="h-16 w-16"
            />
          </div>
          <div>
            <CardTitle className="text-3xl font-bold">Welcome to HabiCord</CardTitle>
            <CardDescription className="mt-2">
              Manage your Roblox game with powerful analytics and automation
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Button 
              onClick={handleRobloxLogin} 
              className="w-full h-14 text-base font-semibold"
              data-testid="button-login-roblox"
            >
              <svg
                className="mr-2 h-5 w-5"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M18.926 23.998L0.002 18.073L5.927 -0.002L24.851 5.923L18.926 23.998ZM9.233 13.194L10.807 13.603L11.216 12.029L9.642 11.62L9.233 13.194Z" />
              </svg>
              Login with Roblox
            </Button>
            <p className="text-xs text-center text-muted-foreground">
              You'll be redirected to Roblox to authorize HabiCord. We'll never access your password.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
