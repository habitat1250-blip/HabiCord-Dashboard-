import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Players() {
  const [searchQuery, setSearchQuery] = useState("");
  const [rankFilter, setRankFilter] = useState("all");

  const { data: players, isLoading } = useQuery({
    queryKey: ["/api/players", searchQuery, rankFilter],
  });

  const mockPlayers = [
    {
      id: "1",
      username: "JohnDoe123",
      displayName: "John Doe",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=JohnDoe123",
      rank: "Officer",
      team: "Alpha",
      activityScore: 850,
      lastSeenAt: "2024-01-15T10:30:00Z",
      isOnline: true,
    },
    {
      id: "2",
      username: "PlayerPro",
      displayName: "Player Pro",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=PlayerPro",
      rank: "Member",
      team: "Bravo",
      activityScore: 620,
      lastSeenAt: "2024-01-15T09:15:00Z",
      isOnline: false,
    },
    {
      id: "3",
      username: "GameMaster",
      displayName: "Game Master",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=GameMaster",
      rank: "Admin",
      team: "Alpha",
      activityScore: 1240,
      lastSeenAt: "2024-01-15T11:45:00Z",
      isOnline: true,
    },
  ];

  const displayPlayers = players || mockPlayers;

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">Players</h1>
        <p className="text-muted-foreground">
          Search and manage all players in your group
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search by username or display name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12"
            data-testid="input-player-search"
          />
        </div>
        <Select value={rankFilter} onValueChange={setRankFilter}>
          <SelectTrigger className="w-full sm:w-48 h-12" data-testid="select-rank-filter">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Filter by rank" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Ranks</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
            <SelectItem value="officer">Officer</SelectItem>
            <SelectItem value="member">Member</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-32" />
              </CardContent>
            </Card>
          ))
        ) : (
          displayPlayers.map((player: any) => (
            <Card key={player.id} className="hover-elevate cursor-pointer" data-testid={`card-player-${player.id}`}>
              <CardContent className="p-6">
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="h-16 w-16 border-2 border-border">
                    <AvatarImage src={player.avatarUrl} alt={player.username} />
                    <AvatarFallback>{player.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold truncate" data-testid={`text-player-username-${player.id}`}>
                      {player.username}
                    </h3>
                    <p className="text-sm text-muted-foreground truncate">
                      {player.displayName}
                    </p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="secondary" className="text-xs">
                        {player.rank}
                      </Badge>
                      {player.isOnline && (
                        <Badge variant="default" className="text-xs">
                          Online
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Team:</span>
                    <span className="font-medium">{player.team}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Activity:</span>
                    <span className="font-medium">{player.activityScore}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Seen:</span>
                    <span className="font-medium">{getTimeAgo(player.lastSeenAt)}</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4" data-testid={`button-view-player-${player.id}`}>
                  View Profile
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
