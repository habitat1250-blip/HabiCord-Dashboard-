import { useQuery } from "@tanstack/react-query";
import { Trophy, Medal, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Leaderboard() {
  const { data: leaderboard } = useQuery({
    queryKey: ["/api/leaderboard"],
  });

  const mockPlayers = [
    {
      rank: 1,
      username: "GameMaster",
      displayName: "Game Master",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=GameMaster",
      activityScore: 1240,
      team: "Alpha",
    },
    {
      rank: 2,
      username: "JohnDoe123",
      displayName: "John Doe",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=JohnDoe123",
      activityScore: 850,
      team: "Alpha",
    },
    {
      rank: 3,
      username: "PlayerPro",
      displayName: "Player Pro",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=PlayerPro",
      activityScore: 620,
      team: "Bravo",
    },
    {
      rank: 4,
      username: "EliteGamer",
      displayName: "Elite Gamer",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=EliteGamer",
      activityScore: 580,
      team: "Charlie",
    },
    {
      rank: 5,
      username: "SkillMaster",
      displayName: "Skill Master",
      avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=SkillMaster",
      activityScore: 520,
      team: "Bravo",
    },
  ];

  const mockTeams = [
    {
      rank: 1,
      name: "Alpha",
      totalScore: 2090,
      playerCount: 15,
      color: "bg-blue-600",
    },
    {
      rank: 2,
      name: "Bravo",
      totalScore: 1850,
      playerCount: 12,
      color: "bg-green-600",
    },
    {
      rank: 3,
      name: "Charlie",
      totalScore: 1620,
      playerCount: 10,
      color: "bg-purple-600",
    },
  ];

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="h-6 w-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="h-6 w-6 text-gray-400" />;
    if (rank === 3) return <Medal className="h-6 w-6 text-amber-700" />;
    return <span className="text-lg font-bold text-muted-foreground w-6 text-center">{rank}</span>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">Leaderboard</h1>
        <p className="text-muted-foreground">
          Top players and teams ranked by activity score
        </p>
      </div>

      <Tabs defaultValue="players" className="space-y-6">
        <TabsList>
          <TabsTrigger value="players" data-testid="tab-players">Players</TabsTrigger>
          <TabsTrigger value="teams" data-testid="tab-teams">Teams</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Top Players
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {mockPlayers.map((player) => (
                  <div
                    key={player.rank}
                    className={`flex items-center gap-4 p-4 rounded-lg hover-elevate ${
                      player.rank <= 3 ? 'bg-muted/50' : ''
                    }`}
                    data-testid={`leaderboard-player-${player.rank}`}
                  >
                    <div className="flex items-center justify-center w-10">
                      {getRankIcon(player.rank)}
                    </div>
                    <Avatar className={player.rank <= 3 ? 'h-16 w-16' : 'h-12 w-12'}>
                      <AvatarImage src={player.avatarUrl} alt={player.username} />
                      <AvatarFallback>{player.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className={`font-semibold truncate ${player.rank <= 3 ? 'text-lg' : ''}`}>
                        {player.username}
                      </h3>
                      <p className="text-sm text-muted-foreground truncate">
                        {player.displayName}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge variant="secondary">{player.team}</Badge>
                      <div className="text-right">
                        <p className={`font-bold ${player.rank <= 3 ? 'text-xl' : 'text-lg'}`}>
                          {player.activityScore}
                        </p>
                        <p className="text-xs text-muted-foreground">points</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="teams" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                Top Teams
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockTeams.map((team) => (
                  <div
                    key={team.rank}
                    className={`flex items-center gap-4 p-6 rounded-lg hover-elevate ${
                      team.rank <= 3 ? 'bg-muted/50' : ''
                    }`}
                    data-testid={`leaderboard-team-${team.rank}`}
                  >
                    <div className="flex items-center justify-center w-10">
                      {getRankIcon(team.rank)}
                    </div>
                    <div className={`${team.color} h-16 w-16 rounded-lg flex items-center justify-center`}>
                      <span className="text-2xl font-bold text-white">
                        {team.name.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className={`font-bold ${team.rank <= 3 ? 'text-xl' : 'text-lg'}`}>
                        Team {team.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {team.playerCount} active players
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${team.rank <= 3 ? 'text-2xl' : 'text-xl'}`}>
                        {team.totalScore}
                      </p>
                      <p className="text-xs text-muted-foreground">total points</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
