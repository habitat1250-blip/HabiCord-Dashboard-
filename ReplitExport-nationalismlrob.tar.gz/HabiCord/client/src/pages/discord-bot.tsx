import { MessageSquare, CheckCircle, ExternalLink } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function DiscordBot() {
  const inviteUrl = "https://discord.com/oauth2/authorize?client_id=1369273807335849994&scope=applications.commands%20bot&permissions=8";

  const features = [
    "Real-time session notifications in your Discord server",
    "Automatic announcements when sessions are hosted",
    "Player activity updates and alerts",
    "Ban and promotion notifications",
    "Integration with all HabiCord features",
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">Discord Bot Integration</h1>
        <p className="text-muted-foreground">
          Connect the HabiCord bot to your Discord server for real-time notifications
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start gap-4">
            <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <MessageSquare className="h-8 w-8 text-primary" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-2xl mb-2">HabiCord Bot</CardTitle>
              <div className="flex items-center gap-3">
                <Badge variant="default" className="bg-green-600">
                  <div className="flex items-center gap-1">
                    <div className="h-2 w-2 rounded-full bg-white animate-pulse" />
                    Online
                  </div>
                </Badge>
                <span className="text-sm text-muted-foreground">Ready to join your server</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-3">Features</h3>
            <ul className="space-y-2">
              {features.map((feature, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-4 border-t">
            <Button 
              size="lg" 
              className="w-full sm:w-auto"
              onClick={() => window.open(inviteUrl, '_blank')}
              data-testid="button-invite-bot"
            >
              <ExternalLink className="mr-2 h-5 w-5" />
              Invite Bot to Server
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Setup Instructions</CardTitle>
          <CardDescription>
            Follow these steps to add the bot to your Discord server
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="space-y-4 text-sm">
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                1
              </span>
              <div>
                <p className="font-medium mb-1">Click "Invite Bot to Server"</p>
                <p className="text-muted-foreground">You'll be redirected to Discord's authorization page</p>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                2
              </span>
              <div>
                <p className="font-medium mb-1">Select your Discord server</p>
                <p className="text-muted-foreground">Choose the server where you want HabiCord notifications</p>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                3
              </span>
              <div>
                <p className="font-medium mb-1">Authorize the bot</p>
                <p className="text-muted-foreground">Grant the necessary permissions for the bot to function properly</p>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground flex-shrink-0 text-xs font-bold">
                4
              </span>
              <div>
                <p className="font-medium mb-1">Configure webhook in Group Settings</p>
                <p className="text-muted-foreground">Go to Group Settings and add your Discord webhook URL to enable notifications</p>
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Example Notification</CardTitle>
          <CardDescription>
            Here's what a session notification looks like in Discord
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-muted p-4 rounded-lg border-l-4 border-primary">
            <div className="flex items-start gap-3">
              <img 
                src="/attached_assets/1761554633390_1762009837448.png" 
                alt="HabiCord" 
                className="h-10 w-10 rounded-full"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold">HabiCord Bot</span>
                  <Badge variant="secondary" className="text-xs">BOT</Badge>
                </div>
                <div className="bg-card p-4 rounded-md border space-y-2">
                  <h4 className="font-bold text-lg">🎮 New Session Started!</h4>
                  <p className="text-sm"><strong>Training Session</strong></p>
                  <p className="text-sm text-muted-foreground">New recruit training for team protocols</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2 border-t">
                    <span>Host: GameMaster</span>
                    <span>•</span>
                    <span>12 players joined</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
