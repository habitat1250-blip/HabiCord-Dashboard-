import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Calendar, Users, Play, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Sessions() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    notifyDiscord: true,
  });
  const { toast } = useToast();

  const { data: sessions, isLoading } = useQuery({
    queryKey: ["/api/sessions"],
  });

  const createSessionMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/sessions", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      setIsDialogOpen(false);
      setFormData({ title: "", description: "", notifyDiscord: true });
      toast({
        title: "Session created",
        description: "Your session has been created successfully.",
      });
    },
  });

  const mockSessions = [
    {
      id: "1",
      title: "Training Session",
      description: "New recruit training for team protocols",
      status: "live",
      playerCount: 12,
      host: {
        username: "GameMaster",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=GameMaster",
      },
      scheduledAt: "2024-01-15T14:00:00Z",
    },
    {
      id: "2",
      title: "Competitive Match",
      description: "Alpha vs Bravo team match",
      status: "upcoming",
      playerCount: 0,
      host: {
        username: "JohnDoe123",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=JohnDoe123",
      },
      scheduledAt: "2024-01-15T16:00:00Z",
    },
    {
      id: "3",
      title: "Community Event",
      description: "Weekly community gathering and Q&A",
      status: "completed",
      playerCount: 25,
      host: {
        username: "AdminUser",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=AdminUser",
      },
      scheduledAt: "2024-01-14T18:00:00Z",
    },
  ];

  const displaySessions = sessions || mockSessions;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createSessionMutation.mutate(formData);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "live":
        return <Badge variant="default" className="bg-green-600">Live</Badge>;
      case "upcoming":
        return <Badge variant="secondary">Upcoming</Badge>;
      case "completed":
        return <Badge variant="outline">Completed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">Sessions</h1>
          <p className="text-muted-foreground">
            Host and manage game sessions with Discord notifications
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" data-testid="button-create-session">
              <Plus className="mr-2 h-5 w-5" />
              Host Session
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>Host a New Session</DialogTitle>
                <DialogDescription>
                  Create a new session and optionally notify your Discord server
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Session Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Training Session"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    data-testid="input-session-title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="What will happen in this session?"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    data-testid="input-session-description"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discord"
                    checked={formData.notifyDiscord}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, notifyDiscord: checked as boolean })
                    }
                    data-testid="checkbox-notify-discord"
                  />
                  <Label htmlFor="discord" className="text-sm font-normal cursor-pointer">
                    Send notification to Discord server
                  </Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createSessionMutation.isPending}>
                  {createSessionMutation.isPending ? "Creating..." : "Create Session"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {displaySessions.map((session: any) => (
          <Card key={session.id} data-testid={`card-session-${session.id}`}>
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <CardTitle className="truncate mb-2">{session.title}</CardTitle>
                  {getStatusBadge(session.status)}
                </div>
                {session.status === "live" && <Play className="h-5 w-5 text-green-600 animate-pulse" />}
                {session.status === "completed" && <CheckCircle className="h-5 w-5 text-muted-foreground" />}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {session.description && (
                <p className="text-sm text-muted-foreground">{session.description}</p>
              )}
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={session.host.avatarUrl} alt={session.host.username} />
                  <AvatarFallback>{session.host.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">Hosted by {session.host.username}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(session.scheduledAt).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>{session.playerCount} players</span>
                </div>
                {session.status !== "completed" && (
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
