import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Shield, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Banlist() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    playerSearch: "",
    reason: "",
    duration: "permanent",
  });
  const { toast } = useToast();

  const { data: bans } = useQuery({
    queryKey: ["/api/bans"],
  });

  const createBanMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/bans", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bans"] });
      setIsDialogOpen(false);
      setFormData({ playerSearch: "", reason: "", duration: "permanent" });
      toast({
        title: "Ban added",
        description: "Player has been added to the banlist.",
      });
    },
  });

  const mockBans = [
    {
      id: "1",
      player: {
        username: "BadPlayer123",
        displayName: "Bad Player",
      },
      reason: "Cheating and exploiting game mechanics",
      duration: "permanent",
      isActive: true,
      createdAt: "2024-01-10T14:30:00Z",
      bannedBy: "AdminUser",
    },
    {
      id: "2",
      player: {
        username: "ToxicUser",
        displayName: "Toxic User",
      },
      reason: "Harassment and toxic behavior",
      duration: "30 days",
      isActive: true,
      createdAt: "2024-01-12T10:15:00Z",
      bannedBy: "GameMaster",
      expiresAt: "2024-02-11T10:15:00Z",
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createBanMutation.mutate(formData);
  };

  const removeBanMutation = useMutation({
    mutationFn: async (banId: string) => {
      return await apiRequest("DELETE", `/api/bans/${banId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bans"] });
      toast({
        title: "Ban removed",
        description: "Player has been removed from the banlist.",
      });
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">Banlist</h1>
          <p className="text-muted-foreground">
            Manage banned players and enforcement actions
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" variant="destructive" data-testid="button-add-ban">
              <Plus className="mr-2 h-5 w-5" />
              Add Ban
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>Add Player Ban</DialogTitle>
                <DialogDescription>
                  Ban a player from the game or group
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="player">Player *</Label>
                  <Input
                    id="player"
                    placeholder="Search for player..."
                    value={formData.playerSearch}
                    onChange={(e) => setFormData({ ...formData, playerSearch: e.target.value })}
                    required
                    data-testid="input-ban-player"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration *</Label>
                  <Select 
                    value={formData.duration} 
                    onValueChange={(value) => setFormData({ ...formData, duration: value })}
                  >
                    <SelectTrigger data-testid="select-ban-duration">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-day">1 Day</SelectItem>
                      <SelectItem value="7-days">7 Days</SelectItem>
                      <SelectItem value="30-days">30 Days</SelectItem>
                      <SelectItem value="permanent">Permanent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reason">Reason *</Label>
                  <Textarea
                    id="reason"
                    placeholder="Why is this player being banned?"
                    value={formData.reason}
                    onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                    required
                    rows={3}
                    data-testid="input-ban-reason"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="destructive" disabled={createBanMutation.isPending}>
                  {createBanMutation.isPending ? "Adding..." : "Add Ban"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {mockBans.map((ban: any) => (
          <Card key={ban.id} data-testid={`card-ban-${ban.id}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-4 flex-1">
                  <div className="h-12 w-12 rounded-lg bg-destructive/10 flex items-center justify-center flex-shrink-0">
                    <Shield className="h-6 w-6 text-destructive" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{ban.player.username}</h3>
                      {ban.isActive ? (
                        <Badge variant="destructive">Active</Badge>
                      ) : (
                        <Badge variant="outline">Expired</Badge>
                      )}
                      <Badge variant="secondary">{ban.duration}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{ban.reason}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Banned by {ban.bannedBy}</span>
                      <span>•</span>
                      <span>{new Date(ban.createdAt).toLocaleDateString()}</span>
                      {ban.expiresAt && (
                        <>
                          <span>•</span>
                          <span>Expires {new Date(ban.expiresAt).toLocaleDateString()}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => removeBanMutation.mutate(ban.id)}
                  disabled={removeBanMutation.isPending}
                  data-testid={`button-remove-ban-${ban.id}`}
                >
                  Remove Ban
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
