import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Calendar, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function LeaveOfAbsence() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    playerSearch: "",
    startDate: "",
    endDate: "",
    reason: "",
  });
  const { toast } = useToast();

  const { data: loaList } = useQuery({
    queryKey: ["/api/loa"],
  });

  const createLoaMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/loa", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loa"] });
      setIsDialogOpen(false);
      setFormData({ playerSearch: "", startDate: "", endDate: "", reason: "" });
      toast({
        title: "LoA created",
        description: "Leave of absence has been recorded.",
      });
    },
  });

  const mockLoaList = [
    {
      id: "1",
      player: {
        username: "JohnDoe123",
        displayName: "John Doe",
      },
      startDate: "2024-01-15",
      endDate: "2024-01-22",
      reason: "Vacation",
      isActive: true,
    },
    {
      id: "2",
      player: {
        username: "PlayerPro",
        displayName: "Player Pro",
      },
      startDate: "2024-01-10",
      endDate: "2024-01-14",
      reason: "School exams",
      isActive: false,
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createLoaMutation.mutate(formData);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">Leave of Absence</h1>
          <p className="text-muted-foreground">
            Manage player absences and track their return dates
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" data-testid="button-add-loa">
              <Plus className="mr-2 h-5 w-5" />
              Add LoA
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>Add Leave of Absence</DialogTitle>
                <DialogDescription>
                  Record a player's planned absence from the game
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="player">Player *</Label>
                  <Input
                    id="player"
                    placeholder="Search for player..."
                    value={formData.playerSearch}
                    onChange={(e) => setFormData({ ...formData, playerSearch: e.target.value })}
                    required
                    data-testid="input-loa-player"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date *</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                      required
                      data-testid="input-loa-start-date"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date *</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                      required
                      data-testid="input-loa-end-date"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reason">Reason *</Label>
                  <Textarea
                    id="reason"
                    placeholder="Why is the player taking leave?"
                    value={formData.reason}
                    onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                    required
                    rows={3}
                    data-testid="input-loa-reason"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createLoaMutation.isPending}>
                  {createLoaMutation.isPending ? "Adding..." : "Add LoA"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {mockLoaList.map((loa: any) => (
          <Card key={loa.id} data-testid={`card-loa-${loa.id}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-lg">{loa.player.username}</h3>
                    {loa.isActive ? (
                      <Badge variant="default">Active</Badge>
                    ) : (
                      <Badge variant="outline">Expired</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{loa.reason}</p>
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{new Date(loa.startDate).toLocaleDateString()}</span>
                      <span className="text-muted-foreground">to</span>
                      <span>{new Date(loa.endDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" data-testid={`button-remove-loa-${loa.id}`}>
                  Remove
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
