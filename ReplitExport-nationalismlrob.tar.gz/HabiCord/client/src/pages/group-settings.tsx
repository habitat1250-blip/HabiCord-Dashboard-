import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Settings, Users, Bot, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function GroupSettings() {
  const [groupId, setGroupId] = useState("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [rankBotId, setRankBotId] = useState("");
  const [rankBotCookie, setRankBotCookie] = useState("");
  const { toast } = useToast();

  const { data: groupSettings } = useQuery({
    queryKey: ["/api/group-settings"],
  });

  const updateGroupMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/group-settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/group-settings"] });
      toast({
        title: "Settings updated",
        description: "Group settings have been saved successfully.",
      });
    },
  });

  const mockSettings = {
    groupId: "123456789",
    groupName: "HabiCord Official Group",
    isConnected: true,
    ownerUsername: "AdminUser",
    rankBotConfigured: true,
    webhookConfigured: true,
    adminCount: 3,
  };

  const handleConnectGroup = () => {
    updateGroupMutation.mutate({
      robloxGroupId: groupId,
    });
  };

  const handleUpdateWebhook = () => {
    updateGroupMutation.mutate({
      discordWebhookUrl: webhookUrl,
    });
  };

  const handleUpdateRankBot = () => {
    updateGroupMutation.mutate({
      rankBotRobloxId: rankBotId,
      rankBotCookie: rankBotCookie,
    });
  };

  const displaySettings = groupSettings || mockSettings;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold mb-2">Group Settings</h1>
        <p className="text-muted-foreground">
          Connect and configure your Roblox group integration
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Roblox Group Connection
          </CardTitle>
          <CardDescription>
            Link your Roblox group to enable admin access and player management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {displaySettings.isConnected ? (
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-1">{displaySettings.groupName}</h3>
                  <p className="text-sm text-muted-foreground mb-2">Group ID: {displaySettings.groupId}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <Badge variant="default">Connected</Badge>
                    <span className="text-muted-foreground">{displaySettings.adminCount} admins have access</span>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Disconnect
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="groupId">Roblox Group ID *</Label>
                <Input
                  id="groupId"
                  placeholder="Enter your group ID"
                  value={groupId}
                  onChange={(e) => setGroupId(e.target.value)}
                  data-testid="input-group-id"
                />
                <p className="text-xs text-muted-foreground">
                  Find your group ID in the URL: roblox.com/groups/<strong>YOUR_ID</strong>/group-name
                </p>
              </div>
              <Button 
                onClick={handleConnectGroup}
                disabled={!groupId || updateGroupMutation.isPending}
                data-testid="button-connect-group"
              >
                {updateGroupMutation.isPending ? "Connecting..." : "Connect Group"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Rank Bot Configuration
          </CardTitle>
          <CardDescription>
            Set up a Roblox bot account to automatically promote players from the dashboard
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {displaySettings.rankBotConfigured && (
            <div className="flex items-center gap-2 p-3 bg-green-600/10 border border-green-600/20 rounded-lg mb-4">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium">Rank bot is configured and active</span>
            </div>
          )}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rankBotId">Bot Account Roblox ID</Label>
              <Input
                id="rankBotId"
                placeholder="Enter bot account user ID"
                value={rankBotId}
                onChange={(e) => setRankBotId(e.target.value)}
                data-testid="input-rank-bot-id"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rankBotCookie">Bot Account Cookie</Label>
              <Input
                id="rankBotCookie"
                type="password"
                placeholder="Enter .ROBLOSECURITY cookie"
                value={rankBotCookie}
                onChange={(e) => setRankBotCookie(e.target.value)}
                data-testid="input-rank-bot-cookie"
              />
              <p className="text-xs text-muted-foreground">
                This cookie is encrypted and stored securely. Never share it with anyone.
              </p>
            </div>
            <Button 
              onClick={handleUpdateRankBot}
              disabled={updateGroupMutation.isPending}
              data-testid="button-update-rank-bot"
            >
              {updateGroupMutation.isPending ? "Saving..." : "Save Rank Bot Settings"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Discord Webhook
          </CardTitle>
          <CardDescription>
            Configure webhook URL for session notifications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {displaySettings.webhookConfigured && (
            <div className="flex items-center gap-2 p-3 bg-green-600/10 border border-green-600/20 rounded-lg mb-4">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium">Discord webhook is configured</span>
            </div>
          )}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="webhookUrl">Webhook URL</Label>
              <Input
                id="webhookUrl"
                placeholder="https://discord.com/api/webhooks/..."
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                data-testid="input-webhook-url"
              />
              <p className="text-xs text-muted-foreground">
                Get this from Discord Server Settings → Integrations → Webhooks
              </p>
            </div>
            <Button 
              onClick={handleUpdateWebhook}
              disabled={updateGroupMutation.isPending}
              data-testid="button-update-webhook"
            >
              {updateGroupMutation.isPending ? "Saving..." : "Save Webhook URL"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
