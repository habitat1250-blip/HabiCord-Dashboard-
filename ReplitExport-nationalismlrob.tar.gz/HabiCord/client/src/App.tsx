import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Players from "@/pages/players";
import Sessions from "@/pages/sessions";
import Leaderboard from "@/pages/leaderboard";
import LeaveOfAbsence from "@/pages/loa";
import Banlist from "@/pages/banlist";
import Promotions from "@/pages/promotions";
import ApiKeys from "@/pages/api-keys";
import GroupSettings from "@/pages/group-settings";
import DiscordBot from "@/pages/discord-bot";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={Dashboard} />
      <Route path="/players" component={Players} />
      <Route path="/sessions" component={Sessions} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/loa" component={LeaveOfAbsence} />
      <Route path="/banlist" component={Banlist} />
      <Route path="/promotions" component={Promotions} />
      <Route path="/api-keys" component={ApiKeys} />
      <Route path="/group-settings" component={GroupSettings} />
      <Route path="/discord-bot" component={DiscordBot} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  const isLoginPage = window.location.pathname === "/login";

  if (isLoginPage) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider defaultTheme="dark">
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar />
              <div className="flex flex-col flex-1 overflow-hidden">
                <header className="flex items-center justify-between p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <ThemeToggle />
                </header>
                <main className="flex-1 overflow-y-auto">
                  <div className="container max-w-7xl mx-auto p-6 md:p-8">
                    <Router />
                  </div>
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
